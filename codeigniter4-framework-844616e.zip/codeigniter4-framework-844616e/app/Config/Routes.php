<?php

use CodeIgniter\Router\RouteCollection;


/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('users', 'UserController::index');
$routes->get('users/usuarios', 'UserController::usuarios');
$routes->get('users/usuarios2','UserController::usuarios2');
$routes->get('users/usurios3','UserController::usuarios3');
$routes->get('posts/01', 'PostController::ejercicios01');
$routes->get('posts/02', 'PostController::ejercicios02');
$routes->get('posts/03', 'PostController::ejercicios03');
$routes->get('posts/04', 'PostController::ejercicios04');
$routes->get('posts/05', 'PostController::ejercicios05');
$routes->get('posts/06', 'PostController::ejercicios06');
$routes->get('posts/07', 'PostController::ejercicios07');
$routes->get('posts/08', 'PostController::ejercicios08');
$routes->get('posts/09', 'PostController::ejercicios09');
$routes->get('posts/10', 'PostController::ejercicios10');




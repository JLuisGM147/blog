<h1>3. Mostrar una tabla con el nombre completo del usuario, su email y teléfono
además del título del post con status 0.</h1>

<br>

<table border="1" width="100%">
    <thead>
        <tr>
            <th>NOMBRE DEL USUARIO</th>
            <th>CORREO ELECTRONICO</th>
            <th>TELEFONO</th>
            <th>TITULO DEL POST</th>
        </tr>
    </thead>

    <tbody>
    <?php foreach($users as $user):?>
        <tr>
            <td><?=$user['usuario'];?></td>
            <td><?=$user['email'];?></td>
            <td><?=$user['phone'];?></td>
            <td><?=$user['title'];?></td>
        </tr>
    <?php endforeach;?>
    </tbody>

    <tfoot>
        <tr>
            <th>NOMBRE DEL USUARIO</th>
            <th>CORREO ELECTRONICO</th>
            <th>TELEFONO</th>
            <th>TITULO DEL POST</th>
        </tr>
    </tfoot>

</table>
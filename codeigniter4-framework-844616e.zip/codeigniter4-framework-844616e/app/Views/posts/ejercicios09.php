<h1>9. En una tabla, mostrar el título del post, contenido del post y el nombre de la
categoria de todos los usuarios cuyo perfil sea administrador. </h1>

<table border="1" whidth="100%">
    <tr>
        <td>Titulo</td>
        <td>Contenido</td>
        <td>Categoría</td>
    </tr>
    <?php foreach ($categoryAdmin as $categories) : ?>
        <tr>
            <td><?= $categories['title'] ?></td>
            <td><?= $categories['content'] ?></td>
            <td><?= $categories['category'] ?></td>
        </tr>
    <?php endforeach; ?>
</table>

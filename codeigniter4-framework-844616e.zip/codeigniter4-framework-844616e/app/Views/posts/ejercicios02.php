<h1>2. Mostrar una tabla con el nombre del post y el nombre completo del autor de
la última categoría registrada en la base de datos</h1>


<br>
    <table border="1" width="100%">   
        <thead>
            <tr>
                <th>NOMBRE DEL POST</th>
                <th>NOMBRE DEL AUTOR</th>
            </tr>

        </thead>     

        <tbody>
            <?php foreach($posts as $post): ?>
                <tr>
                    <td><?= $post['title']; ?></td>
                    <td><?= $post['autor']; ?></td>
                </tr>
            <?php endforeach; ?>
            
        </tbody>

        <tfoot>
            <tr>
                <th>NOMBRE DEL POST</th>
                <th>NOMBRE DEL AUTOR</th>
            </tr>
        </tfoot>

    </table>



</br>
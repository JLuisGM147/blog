<h1>8. Mostrar una tabla con un resumen de las cantidades de posts escritos por
categoría y otro resumen de posts escritos por autor. Resaltar con un color
distinto el valor más alto y el más bajo en ambos resumenes.</h1>

<table border="1" width="100%">
    <tr>
        <td>Escrito por</td>
        <td>Cantidad de post</td>
    </tr>
    <tr>
        <td>Categosria</td>
        <td>
            <?php foreach ($resumenporCategory as $rppc) : ?>
                <td>
                    <?= $rppc["category"] ?>
                </td>
                <?php if ($rppc["rppc"] == $maxCategory) : ?>
                    <td style="background-color: red; color: white;">
                        <?= $rppc["rppc"] ?>
                    </td>
                <?php elseif ($rppc["rppc"] == $minCategoria) : ?>
                    <td style="background-color: green; color: white;">
                        <?= $rppc["rppc"] ?>
                    </td>
                <?php else : ?>
                    <td>
                        <?= $rppc["rppc"] ?>
                    </td>
                <?php endif; ?>
            <?php endforeach; ?>
        </td>
        <td>Autor</td>
        <td>
            <?php foreach ($resumenporAutor as $rppa) : ?>
                <td>
                    <?= $rppa["name"] ?>
                </td>
                <?php if ($rppa["rppa"] == $maxAutor) : ?>
                    <td style="background-color: red; color: white;">
                        <?= $rppa["rppa"] ?>
                    </td>
                <?php elseif ($rppa["rppa"] == $minAutor) : ?>
                    <td style="background-color: green; color: white;">
                        <?= $rppa["rppa"] ?>
                    </td>
                <?php else : ?>
                    <td>
                        <?= $rppa["rppa"] ?>
                    </td>
                <?php endif; ?>
            <?php endforeach; ?>
        </td>
    </tr>
</table>
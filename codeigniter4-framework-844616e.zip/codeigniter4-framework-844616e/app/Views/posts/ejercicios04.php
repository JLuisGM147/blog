<h1>Mostrar una tabla con el username, nombre completo del usuario, el email y
una columna con el género (hombre/mujer) de todos los posts creados en el
año 2022.</h1>
    <br>


    <table>
        <thead>
            <tr>
                <th>USERNAME</th>
                <th>NOMBRE DEL USUARIO</th>
                <th>CORREO ELECTRONICO</th>
                <th>GENERO</th>
                
            </tr>
        </thead>

        <tbody>
            <?php foreach($users as $post): ?>
                <tr>
                    <th><?= $post['username'];?></th>
                    <th><?= $post['name'];?></th>
                    <th><?= $post['email'];?></th>
                    <th><?= $post['gender'];?></th>

                </tr>
            <?php endforeach; ?>

        </tbody>
        <tfoot>
            <tr>
                <th>USERNAME</th>
                <th>NOMBRE DEL USUARIO</th>
                <th>CORREO ELECTRONICO</th>
                <th>GENERO</th></th>
            </tr>
        </tfoot>
    </table>

<?php


namespace App\Controllers;
use App\Models\UserModel;

class UserController extends BaseController{
    
    public function index(){

        $usuario = new UserModel();
        $usuarios = $usuario->findAll();

       $data = [
        'usuarios' =>$usuarios
       ];

       return view('users/index', $usuarios);
    
    }

    public function usuarios(){
        $db = \Config\Database::connect();
        $db->query('SELECT * FROM users')->getResultArray();
        $usuario = new UserModel();
        $usuarios = $usuario->findAll();

        $data=[
            'usuarios' => $usuarios
        ];
        
        return view('users/usuarios', $data);
        dd($data);

        }

    public function usuarios2(){
        $db = \Config\Database::connect();
        $db->query('SELECT username, password, srarus, FROM users')->getResultArray();

        
        $usuario = new UserModel();
        $usuarios = $usuario->findAll();
        $data=[
            'usuarios' => $usuarios
        ];
        
        return view('users/usuarios', $data);



        dd($db);

        
    }

    public function usuarios3(){
        $db = \Config\Database::connect(); 
        $usuarios = $db->query('SELECT * FROM users AS u JOIN userinfo AS ui ON u.id = ui.id') ->getResultArray();

        $data = [

            'usuarios' => $usuarios
        ];

        return view('users/usuarios3', $data);

    }
}

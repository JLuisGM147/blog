<?php
namespace App\Controllers;

class PostController extends BaseController
{
    public function ejercicios01()
    {
            $db = \Config\Database:: connect();
            $posts = $db->query('SELECT c.category, p.id, p.title, u.username FROM categories AS c RIGHT JOIN posts AS p ON p.category = c.id JOIN users AS u ON u.id = p.autor WHERE p.created_at BETWEEN "2023-01-01" AND "2023-12-31" ')->getResultArray();
       // $posts = $db->query('select * from categories as c left join categories as c on p.category = c.id')->getResultArray();

        $posts2 = $db->query('SELECT * FROM posts LIMIT 10')->getResultArray();

        $data = [
                'posts' =>$posts
            ];
            
            return view('posts/ejercicios01', $data);
            dd($posts);
     
    
    }

    public function ejercicios02(){
        $db = \Config\Database::connect();
        $ultimoregistro=$db->query('SELECT id from categories ORDER BY id des limit 1');
        $ultimaCategory = $db->query('SELECT p.title, CONCAT(u.name, " ", u.lastname), FROM posts AS p
        JOIN users AS u ON p.autor = u.id JOIN userinfo as ui ON u.id =ui.id
        where p.category=($ultimoregistro)');

        $data = [
            'ultimaCategoria' => $ultimaCategory

        ];

        return view('posts/ejercicios02');
    }
    
    public function ejercicios03(){
        $db = \Config\Database::connect();
        $posts = $db->query('SELECT CONCAT(u.name," ",u.lastname), u.email, u.phone, p.title 
        FROM users AS u JOIN userinfo AS ui on u.id = ui.id 
        JOIN posts AS p ON  u.id=p.autor WHERE p.status= 0');

        $data = [
            'posts' => $posts

        ];
        return view('posts/ejercicios03');
        
    }
    
    public function ejercicios04(){
        $db = \Config\Database::connect();
        $postsCreadosPorHombres = $db->query('SELECT u.*, p.*, CONCAT(u.name," ",u.lastname)
        FROM users AS u JOIN userinfo as ui on u.id = ui.id
        JOIN posts AS p ON u.id = p.autor 
         WHERE u.gender = "m" AND p.created_at BETWEEN "2022-01-01" and "2022-12-31"');

        $postsCreadosPorMujeres = $db->query('SELECT u.*,p.*, CONCAT(u.name," ",u.lastname)
        FROM users AS u JOIN userinfo as ui on u.id = ui.id
        JOIN posts AS p ON u.id = p.autor 
         WHERE u.gender = "f" AND p.created_at BETWEEN "2022-01-01" and "2022-12-31"');

        $data =[
            'postsCreadosPorHombres' =>$postsCreadosPorHombres,
            'postsCreadosPorMujeres' =>$postsCreadosPorMujeres,
        ];

        return view('posts/ejercicios04');
    }


	public function ejercicio05()
	{
		// 5. Mostrar una tabla con los siguientes datos: cantidad total de usuarios registrados, cantidad total de posts, cantidad total de comentarios, cantidad total de categorias.

		$db = \Config\Database::connect();

		$totalUsers = $db->query('SELECT count(*) as "totalUsuarios" from users')->getResultArray();

		$totalPosts = $db->query('SELECT count(*) as "totalPublicaciones" from posts')->getResultArray();
		
		$totalComments = $db->query('SELECT count(*) as "totalComentarios" from comments')->getResultArray();

		$totalCategories = $db->query('SELECT count(*) as "totalCategorias" from categories')->getResultArray();

		$data = [
			'totalUsers'		=> $totalUsers,
			'totalPosts'		=> $totalPosts,
			'totalComments'		=> $totalComments,
			'totalCategories'	=> $totalCategories
		];

		return view('posts/ejercicio05', $data);
	}

    
    public function ejercicio06()
	{
		$db = \Config\Database::connect();

		$postsPorCategoria = $db->query('SELECT p.*, c.category as category, count(*) as ppc 
        from categories as c join posts as p on p.category = c.id group by category 
        order by category')->getResultArray();

		$postsPorAutor = $db->query('SELECT p.*, u.username as autor, COUNT(*) as ppa 
        from users as u join posts as p on u.id = p.autor GROUP BY autor order by autor')->getResultArray();

		$data = [
			'postsPorCategoria' => $postsPorCategoria,
			'postsPorAutor' 	=> $postsPorAutor
		];

		return view('posts/ejercicio06', $data);
	}
    
    public function ejercicio07()
	{
		$db = \Config\Database::connect();

		$postsEscritosPorMujeres2022 = $db->query('select p.*, count(*) as pepm22, u.*, ui.* from posts as p join users as u on p.autor = u.id join userinfo as ui on u.id = ui.id where ui.gender = "f" and p.created_at between "2022/01/01" and "2022/12/31"')->getResultArray();

		$postsEscritosPorMujeres2023 = $db->query('select p.*, count(*) as pepm23, u.*, ui.* from posts as p join users as u on p.autor = u.id join userinfo as ui on u.id = ui.id where ui.gender = "f" and p.created_at between "2023/01/01" and "2023/12/31"')->getResultArray();

		$postsEscritosPorHombres = $db->query('select p.*, count(*) as peph, u.*, ui.* from posts as p join users as u on p.autor = u.id join userinfo as ui on u.id = ui.id where ui.gender = "m" and p.created_at between "2022/01/01" and "2022/12/31"')->getResultArray();

		$postsEscritosPorMujeres2 = $db->query('select p.*, p.title as titulo, p.created_at as creado, u.*, ui.* from posts as p join users as u on p.autor = u.id join userinfo as ui on u.id = ui.id where ui.gender = "f" and p.created_at between "2022/01/01" and "2022/12/31" order by creado ASC')->getResultArray();

		$data = [
			'postsEscritosPorMujeres2022'	=> $postsEscritosPorMujeres2022,
			'postsEscritosPorMujeres2023'	=> $postsEscritosPorMujeres2023,
			'postsEscritosPorMujeres2'		=> $postsEscritosPorMujeres2,
			'postsEscritosPorHombres'		=> $postsEscritosPorHombres,
		];

		return view('posts/ejercicio07', $data);
	}


    
    public function ejercicios08(){
    
        $db = \Config\Database::connect();
        $resumenporCategory=$db->query('SELECT c.category, count(*) as rppc
        from categories as c join posts as p on p.category = c.id group by rppc order by rppc asc');
        
        $resumenporAutor = $db->query('SELECT u.name, COUNT(*) AS rppa 
        FROM users u JOIN posts p ON p.autor = ui.id GROUP BY rppa ORDER BY rppa asc');
      
        $data =[
            'resumenporCategory'    => $resumenporCategory,
            'resumenporAutor'       => $resumenporAutor,
        ];

        return view('posts/ejercicios08');
        
    }
    
    public function ejercicios09(){
        $db = \Config\Database::connect();
        $categoryAdmin=$db->query('SELECT p* c.category 
        FROM posts AS p JOIN categories as c ON p.category = c.id 
        JOIN users u on p.autor =u.id JOIN profiles as pr ON u.prifile = pr.id  where pr.profile = 1');

        $data = [
            'categoryAdmin' => $categoryAdmin,
        ];
        return view('posts/ejercicios09');
    }
    
    public function ejercicios10(){
        
    }
}

